<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>PT. Ujung Berung</title>

    <!-- Bootstrap 3.0.2 -->
    <link href="<?= base_url("css/bootstrap.min.css") ?>" rel="stylesheet" type="text/css" />

    <!-- Font Awesome -->
    <link href="<?= base_url("css/font-awesome.min.css") ?>" rel="stylesheet" type="text/css" />

    <!-- Ionicons -->
    <link href="<?= base_url("css/ionicons.min.css") ?>" rel="stylesheet" type="text/css" />

    <!-- Theme style -->
    <link href="<?= base_url("css/AdminLTE.css") ?>" rel="stylesheet" type="text/css" />
</head>
<body>
    <!-- Konten halaman Anda akan dimulai di sini -->
</body>
</html>
