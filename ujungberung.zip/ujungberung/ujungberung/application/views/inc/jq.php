<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT. Ujung Berung</title>
</head>
<body>
    <!-- jQuery -->
    <script src="js/jquery.min.js" type="text/javascript"></script>
    
    <!-- jQuery UI -->
    <script src="js/jquery-ui.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>

    <script src="js/chart.min.js" type="text/javascript"></script>
    
    <script src="js/sidebar.js" type="text/javascript"></script>

</body>
</html>
